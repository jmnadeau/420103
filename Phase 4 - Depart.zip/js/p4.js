﻿var the_black_keys = {	nom: "The Black Keys", 
						bio: "The Black Keys est un groupe de blues rock américain, originaire d'Akron, dans l'État de l'Ohio. Le groupe est composé du chanteur et guitariste Dan Auerbach et du batteur Patrick Carney.",
						image: "theblackkeys.jpg",
						extrait: "Tighten Up",
						video: "https://www.youtube.com/embed/mpaPBCBjSVc"};
						
var arctic_monkeys = {	nom: "Arctic Monkeys", 
						bio: "Arctic Monkeys est un groupe de rock britannique, originaire de Sheffield, South Yorkshire, en Angleterre. Il est formé en 2002, plus précisément à High Green, une banlieue de Sheffield.",
						image: "arcticmonkeys.jpg",
						extrait: "Do I Wanna Know",
						video: "https://www.youtube.com/embed/bpOSxM0rNPM"};
						
var panthogram = {	nom: "Phantogram", 
						bio: "Phantogram est un groupe de rock électronique américain, originaire de Saratoga Springs, dans l'État de New York. Il est composé de Josh Carter et Sarah Barthel. Le batteur Tim Oakley accompagne le groupe uniquement lors de spectacles.",
						image: "phantogram.jpg",
						extrait: "When I'm Small",
						video: "https://www.youtube.com/embed/28tZ-S1LFok"};
						
var louis_the_child = {	nom: "Louis The Child", 
						bio: "Louis The Child est un duo de musique basé à Chicago composé de Robby Hauldren et Freddy Kennett. Ils sont surtout connus pour leurs singles, It's Strange, Weekend et Fire.",
						image: "louisthechild.jpg",
						extrait: "It's Strange",
						video: "https://www.youtube.com/embed/rhrqbcufZXo"};
						
var max_frost = {	nom: "Max Frost", 
						bio: "Matthew Alexander \"Max\" Frost est un chanteur, compositeur, producteur et multi-instrumentiste d' Austin, au Texas , qui est signé à Atlantic Records . Il a sorti deux EP: Low High Low en octobre 2013 et Intoxication en septembre 2015.",
						image: "maxfrost.jpg",
						extrait: "White Lies",
						video: "https://www.youtube.com/embed/DDeV0sEjplI"};

var arcade_fire = {	nom: "Arcade Fire", 
						bio: "Arcade Fire, anciennement The Arcade Fire, est un groupe de rock indépendant canadien, originaire de Montréal, au Québec.",
						image: "arcadefire.jpg",
						extrait: "Creature Comfort",
						video: "https://www.youtube.com/embed/xzwicesJQ7E"};
						
var miike_snow = {	nom: "Miike Snow", 
						bio: "Miike Snow est un groupe musical originaire de Stockholm baptisé en hommage au réalisateur Takashi Miike. Il est composé de Andrew Wyatt, Christian Karlsson et Pontus Winnberg.",
						image: "miikesnow.jpg",
						extrait: "My Trigger",
						video: "https://www.youtube.com/embed/wl6k_h2drK8"};
						
var portugal_the_man = {	nom: "Portugal. The Man", 
						bio: "Portugal. The Man est un groupe de rock américain originaire de Wasilla en Alaska. Le groupe est actuellement composé de John Gourley, Zach Carothers, Kyle O'Quin et Jason Sechrist.",
						image: "portugaltheman.jpg",
						extrait: "Feel It Still",
						video: "https://www.youtube.com/embed/pBkHHoOIIn8"};
						
var lewis_del_mar = {	nom: "Lewis Del Mar", 
						bio: "Lewis Del Mar est unl duo américain expérimental pop de Rockaway Beach , New York. Composé du chanteur et guitariste Danny Miller et du batteur et producteur Max Harwood, le groupe a d'abord attiré l'attention au début de l'année 2015 lorsque leur premier single, Loud(y) , figurait au premier rang de Hype Machine .",
						image: "lewisdelmar.jpg",
						extrait: "Loud(y)",                     
						video: "https://www.youtube.com/embed/PagwbIPbEVw"};			
												
var liste_musique = [the_black_keys, arctic_monkeys, panthogram, louis_the_child, max_frost, arcade_fire, portugal_the_man, miike_snow, lewis_del_mar];

$(document).ready(function() {
	
});